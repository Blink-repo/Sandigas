import { eventHandler, createError } from 'h3';
import { withLeadingSlash, withoutTrailingSlash, parseURL } from 'ufo';
import { promises } from 'fs';
import { resolve, dirname } from 'pathe';
import { fileURLToPath } from 'url';

const assets = {
  "/_nuxt/entry-f564636c.mjs": {
    "type": "application/javascript",
    "etag": "\"1ddb9-D47Tz9AWKal1EPUdqwncqXRU+30\"",
    "mtime": "2022-05-13T18:17:51.513Z",
    "path": "../public/_nuxt/entry-f564636c.mjs"
  },
  "/_nuxt/entry.26e20241.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"69e0-9t6AxPYqzmZMpTV1m3l8OTBgHbo\"",
    "mtime": "2022-05-13T18:17:51.512Z",
    "path": "../public/_nuxt/entry.26e20241.css"
  },
  "/_nuxt/index-ee711130.mjs": {
    "type": "application/javascript",
    "etag": "\"4d8d-GEyg4niFYtWdMrNaTSo8ixcVbK0\"",
    "mtime": "2022-05-13T18:17:51.485Z",
    "path": "../public/_nuxt/index-ee711130.mjs"
  },
  "/_nuxt/manifest.json": {
    "type": "application/json",
    "etag": "\"1be-pRdFz3bwIca+tzUVw0U4yQ4A4ps\"",
    "mtime": "2022-05-13T18:17:51.484Z",
    "path": "../public/_nuxt/manifest.json"
  },
  "/img/PlumberMan.png": {
    "type": "image/png",
    "etag": "\"23b52-Vk4Vewt3FsCt6786fIsH8CXvX+8\"",
    "mtime": "2022-05-13T18:17:51.532Z",
    "path": "../public/img/PlumberMan.png"
  },
  "/img/PlumberManThemed.png": {
    "type": "image/png",
    "etag": "\"536e9-HPHidf0E5P9aTwe8tsHTDltyoI0\"",
    "mtime": "2022-05-13T18:17:51.530Z",
    "path": "../public/img/PlumberManThemed.png"
  },
  "/img/Wave (1).svg": {
    "type": "image/svg+xml",
    "etag": "\"396-7cWO5VzU4N3Z2uKW2v4xNziFyro\"",
    "mtime": "2022-05-13T18:17:51.528Z",
    "path": "../public/img/Wave (1).svg"
  },
  "/img/Wave.svg": {
    "type": "image/svg+xml",
    "etag": "\"37f-pxuQp5W1pOlzezXcRx1KfmzFV58\"",
    "mtime": "2022-05-13T18:17:51.527Z",
    "path": "../public/img/Wave.svg"
  },
  "/img/landing.svg": {
    "type": "image/svg+xml",
    "etag": "\"b79f-4UQCPxrNI6gJvoW4EFFqZAxTXu8\"",
    "mtime": "2022-05-13T18:17:51.527Z",
    "path": "../public/img/landing.svg"
  },
  "/img/landing2.webp": {
    "type": "image/webp",
    "etag": "\"b2fe-QKxuYOeFazgHlbmHBhRA7nVVZ3k\"",
    "mtime": "2022-05-13T18:17:51.526Z",
    "path": "../public/img/landing2.webp"
  },
  "/img/landingsplit.svg": {
    "type": "image/svg+xml",
    "etag": "\"457-MWqFAfKcc2TWXP73EmNkOMDmUI8\"",
    "mtime": "2022-05-13T18:17:51.525Z",
    "path": "../public/img/landingsplit.svg"
  },
  "/img/layered-waves.svg": {
    "type": "image/svg+xml",
    "etag": "\"a7e-SKO1pfcV68tH6+vurvUC3z7a22s\"",
    "mtime": "2022-05-13T18:17:51.525Z",
    "path": "../public/img/layered-waves.svg"
  },
  "/img/layered-waves2.svg": {
    "type": "image/svg+xml",
    "etag": "\"a1a-qIu8h1Cmb3zsn+NDwhfb8TuEYLg\"",
    "mtime": "2022-05-13T18:17:51.524Z",
    "path": "../public/img/layered-waves2.svg"
  },
  "/img/plumber.svg": {
    "type": "image/svg+xml",
    "etag": "\"bf96-jSvdJKH0GnAbp96ypsaFlIpLXZM\"",
    "mtime": "2022-05-13T18:17:51.519Z",
    "path": "../public/img/plumber.svg"
  },
  "/img/plumbers.svg": {
    "type": "image/svg+xml",
    "etag": "\"b79f-4UQCPxrNI6gJvoW4EFFqZAxTXu8\"",
    "mtime": "2022-05-13T18:17:51.518Z",
    "path": "../public/img/plumbers.svg"
  },
  "/img/test.svg": {
    "type": "image/svg+xml",
    "etag": "\"275-nAYNNLUIU6uq0x5Wa0OjfYrUiSM\"",
    "mtime": "2022-05-13T18:17:51.518Z",
    "path": "../public/img/test.svg"
  },
  "/img/tilt.svg": {
    "type": "image/svg+xml",
    "etag": "\"e2-MtWJcp6A/AJr1gZjGDQSeTqmrlU\"",
    "mtime": "2022-05-13T18:17:51.517Z",
    "path": "../public/img/tilt.svg"
  },
  "/img/tilttop.svg": {
    "type": "image/svg+xml",
    "etag": "\"e2-9Lh+YJVHOZQxF8qi9ICT4dfDDyg\"",
    "mtime": "2022-05-13T18:17:51.517Z",
    "path": "../public/img/tilttop.svg"
  },
  "/img/wavesOpacity.svg": {
    "type": "image/svg+xml",
    "etag": "\"457-6TEp/EQq+QTyBX/Vomr2kZPyNn4\"",
    "mtime": "2022-05-13T18:17:51.516Z",
    "path": "../public/img/wavesOpacity.svg"
  },
  "/img/wavesbottom.svg": {
    "type": "image/svg+xml",
    "etag": "\"17c-+vd8MrcrqeowuKNb5k6ojiVvrFE\"",
    "mtime": "2022-05-13T18:17:51.516Z",
    "path": "../public/img/wavesbottom.svg"
  },
  "/img/wavestop.svg": {
    "type": "image/svg+xml",
    "etag": "\"17c-+wYITfYhuFnTMP6+dOPEB6fODxc\"",
    "mtime": "2022-05-13T18:17:51.515Z",
    "path": "../public/img/wavestop.svg"
  },
  "/_nuxt/img/PlumberMan.png": {
    "type": "image/png",
    "etag": "\"23b52-Vk4Vewt3FsCt6786fIsH8CXvX+8\"",
    "mtime": "2022-05-13T18:17:51.511Z",
    "path": "../public/_nuxt/img/PlumberMan.png"
  },
  "/_nuxt/img/PlumberManThemed.png": {
    "type": "image/png",
    "etag": "\"536e9-HPHidf0E5P9aTwe8tsHTDltyoI0\"",
    "mtime": "2022-05-13T18:17:51.509Z",
    "path": "../public/_nuxt/img/PlumberManThemed.png"
  },
  "/_nuxt/img/Wave (1).svg": {
    "type": "image/svg+xml",
    "etag": "\"396-7cWO5VzU4N3Z2uKW2v4xNziFyro\"",
    "mtime": "2022-05-13T18:17:51.507Z",
    "path": "../public/_nuxt/img/Wave (1).svg"
  },
  "/_nuxt/img/Wave.svg": {
    "type": "image/svg+xml",
    "etag": "\"37f-pxuQp5W1pOlzezXcRx1KfmzFV58\"",
    "mtime": "2022-05-13T18:17:51.507Z",
    "path": "../public/_nuxt/img/Wave.svg"
  },
  "/_nuxt/img/landing.svg": {
    "type": "image/svg+xml",
    "etag": "\"b79f-4UQCPxrNI6gJvoW4EFFqZAxTXu8\"",
    "mtime": "2022-05-13T18:17:51.506Z",
    "path": "../public/_nuxt/img/landing.svg"
  },
  "/_nuxt/img/landing2.webp": {
    "type": "image/webp",
    "etag": "\"b2fe-QKxuYOeFazgHlbmHBhRA7nVVZ3k\"",
    "mtime": "2022-05-13T18:17:51.504Z",
    "path": "../public/_nuxt/img/landing2.webp"
  },
  "/_nuxt/img/landingsplit.svg": {
    "type": "image/svg+xml",
    "etag": "\"457-MWqFAfKcc2TWXP73EmNkOMDmUI8\"",
    "mtime": "2022-05-13T18:17:51.503Z",
    "path": "../public/_nuxt/img/landingsplit.svg"
  },
  "/_nuxt/img/layered-waves.svg": {
    "type": "image/svg+xml",
    "etag": "\"a7e-SKO1pfcV68tH6+vurvUC3z7a22s\"",
    "mtime": "2022-05-13T18:17:51.503Z",
    "path": "../public/_nuxt/img/layered-waves.svg"
  },
  "/_nuxt/img/layered-waves2.svg": {
    "type": "image/svg+xml",
    "etag": "\"a1a-qIu8h1Cmb3zsn+NDwhfb8TuEYLg\"",
    "mtime": "2022-05-13T18:17:51.502Z",
    "path": "../public/_nuxt/img/layered-waves2.svg"
  },
  "/_nuxt/img/plumber.svg": {
    "type": "image/svg+xml",
    "etag": "\"bf96-jSvdJKH0GnAbp96ypsaFlIpLXZM\"",
    "mtime": "2022-05-13T18:17:51.494Z",
    "path": "../public/_nuxt/img/plumber.svg"
  },
  "/_nuxt/img/plumbers.svg": {
    "type": "image/svg+xml",
    "etag": "\"b79f-4UQCPxrNI6gJvoW4EFFqZAxTXu8\"",
    "mtime": "2022-05-13T18:17:51.493Z",
    "path": "../public/_nuxt/img/plumbers.svg"
  },
  "/_nuxt/img/test.svg": {
    "type": "image/svg+xml",
    "etag": "\"275-nAYNNLUIU6uq0x5Wa0OjfYrUiSM\"",
    "mtime": "2022-05-13T18:17:51.492Z",
    "path": "../public/_nuxt/img/test.svg"
  },
  "/_nuxt/img/tilt.svg": {
    "type": "image/svg+xml",
    "etag": "\"e2-MtWJcp6A/AJr1gZjGDQSeTqmrlU\"",
    "mtime": "2022-05-13T18:17:51.490Z",
    "path": "../public/_nuxt/img/tilt.svg"
  },
  "/_nuxt/img/tilttop.svg": {
    "type": "image/svg+xml",
    "etag": "\"e2-9Lh+YJVHOZQxF8qi9ICT4dfDDyg\"",
    "mtime": "2022-05-13T18:17:51.489Z",
    "path": "../public/_nuxt/img/tilttop.svg"
  },
  "/_nuxt/img/wavesOpacity.svg": {
    "type": "image/svg+xml",
    "etag": "\"457-6TEp/EQq+QTyBX/Vomr2kZPyNn4\"",
    "mtime": "2022-05-13T18:17:51.488Z",
    "path": "../public/_nuxt/img/wavesOpacity.svg"
  },
  "/_nuxt/img/wavesbottom.svg": {
    "type": "image/svg+xml",
    "etag": "\"17c-+vd8MrcrqeowuKNb5k6ojiVvrFE\"",
    "mtime": "2022-05-13T18:17:51.488Z",
    "path": "../public/_nuxt/img/wavesbottom.svg"
  },
  "/_nuxt/img/wavestop.svg": {
    "type": "image/svg+xml",
    "etag": "\"17c-+wYITfYhuFnTMP6+dOPEB6fODxc\"",
    "mtime": "2022-05-13T18:17:51.487Z",
    "path": "../public/_nuxt/img/wavestop.svg"
  },
  "/img/logos/desco.png": {
    "type": "image/png",
    "etag": "\"29f6-h4qm8WryxjSl33vWAT9nrR4Q9FM\"",
    "mtime": "2022-05-13T18:17:51.524Z",
    "path": "../public/img/logos/desco.png"
  },
  "/img/logos/logo.png": {
    "type": "image/png",
    "etag": "\"10402-JF8ekH+Rh/GTiaEfAydcBZKzZFk\"",
    "mtime": "2022-05-13T18:17:51.523Z",
    "path": "../public/img/logos/logo.png"
  },
  "/img/logos/logo_marcke.png": {
    "type": "image/png",
    "etag": "\"597b-1Ok7sJsDLNPYHuJ4FiB/UBJFbRs\"",
    "mtime": "2022-05-13T18:17:51.522Z",
    "path": "../public/img/logos/logo_marcke.png"
  },
  "/img/logos/logo_oirshot.png": {
    "type": "image/png",
    "etag": "\"1a80-JjRBUXkZOPatQYTwfJVaIICt1h4\"",
    "mtime": "2022-05-13T18:17:51.522Z",
    "path": "../public/img/logos/logo_oirshot.png"
  },
  "/img/logos/logo_oirshot_upscale.png": {
    "type": "image/png",
    "etag": "\"342b-q4F1h1UhFTFId4fekdIc3u/03Uo\"",
    "mtime": "2022-05-13T18:17:51.521Z",
    "path": "../public/img/logos/logo_oirshot_upscale.png"
  },
  "/img/logos/logo_partner2.png": {
    "type": "image/png",
    "etag": "\"d72d-vFHP2inQypKOMz8o7cV0srosj94\"",
    "mtime": "2022-05-13T18:17:51.521Z",
    "path": "../public/img/logos/logo_partner2.png"
  },
  "/img/logos/marcke.webp": {
    "type": "image/webp",
    "etag": "\"5706-518e9Iz5ILDvcTToDDv5SRgfGns\"",
    "mtime": "2022-05-13T18:17:51.520Z",
    "path": "../public/img/logos/marcke.webp"
  },
  "/_nuxt/img/logos/desco.png": {
    "type": "image/png",
    "etag": "\"29f6-h4qm8WryxjSl33vWAT9nrR4Q9FM\"",
    "mtime": "2022-05-13T18:17:51.501Z",
    "path": "../public/_nuxt/img/logos/desco.png"
  },
  "/_nuxt/img/logos/logo.png": {
    "type": "image/png",
    "etag": "\"10402-JF8ekH+Rh/GTiaEfAydcBZKzZFk\"",
    "mtime": "2022-05-13T18:17:51.500Z",
    "path": "../public/_nuxt/img/logos/logo.png"
  },
  "/_nuxt/img/logos/logo_marcke.png": {
    "type": "image/png",
    "etag": "\"597b-1Ok7sJsDLNPYHuJ4FiB/UBJFbRs\"",
    "mtime": "2022-05-13T18:17:51.499Z",
    "path": "../public/_nuxt/img/logos/logo_marcke.png"
  },
  "/_nuxt/img/logos/logo_oirshot.png": {
    "type": "image/png",
    "etag": "\"1a80-JjRBUXkZOPatQYTwfJVaIICt1h4\"",
    "mtime": "2022-05-13T18:17:51.498Z",
    "path": "../public/_nuxt/img/logos/logo_oirshot.png"
  },
  "/_nuxt/img/logos/logo_oirshot_upscale.png": {
    "type": "image/png",
    "etag": "\"342b-q4F1h1UhFTFId4fekdIc3u/03Uo\"",
    "mtime": "2022-05-13T18:17:51.498Z",
    "path": "../public/_nuxt/img/logos/logo_oirshot_upscale.png"
  },
  "/_nuxt/img/logos/logo_partner2.png": {
    "type": "image/png",
    "etag": "\"d72d-vFHP2inQypKOMz8o7cV0srosj94\"",
    "mtime": "2022-05-13T18:17:51.497Z",
    "path": "../public/_nuxt/img/logos/logo_partner2.png"
  },
  "/_nuxt/img/logos/marcke.webp": {
    "type": "image/webp",
    "etag": "\"5706-518e9Iz5ILDvcTToDDv5SRgfGns\"",
    "mtime": "2022-05-13T18:17:51.496Z",
    "path": "../public/_nuxt/img/logos/marcke.webp"
  }
};

const mainDir = dirname(fileURLToPath(globalThis.entryURL));
function readAsset (id) {
  return promises.readFile(resolve(mainDir, assets[id].path)).catch(() => {})
}

const publicAssetBases = ["/_nuxt"];

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return
  }
  for (const base of publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = ["HEAD", "GET"];
const _static = eventHandler(async (event) => {
  if (event.req.method && !METHODS.includes(event.req.method)) {
    return;
  }
  let id = decodeURIComponent(withLeadingSlash(withoutTrailingSlash(parseURL(event.req.url).pathname)));
  let asset;
  for (const _id of [id, id + "/index.html"]) {
    const _asset = getAsset(_id);
    if (_asset) {
      asset = _asset;
      id = _id;
      break;
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      throw createError({
        statusMessage: "Cannot find static asset " + id,
        statusCode: 404
      });
    }
    return;
  }
  const ifNotMatch = event.req.headers["if-none-match"] === asset.etag;
  if (ifNotMatch) {
    event.res.statusCode = 304;
    event.res.end("Not Modified (etag)");
    return;
  }
  const ifModifiedSinceH = event.req.headers["if-modified-since"];
  if (ifModifiedSinceH && asset.mtime) {
    if (new Date(ifModifiedSinceH) >= new Date(asset.mtime)) {
      event.res.statusCode = 304;
      event.res.end("Not Modified (mtime)");
      return;
    }
  }
  if (asset.type) {
    event.res.setHeader("Content-Type", asset.type);
  }
  if (asset.etag) {
    event.res.setHeader("ETag", asset.etag);
  }
  if (asset.mtime) {
    event.res.setHeader("Last-Modified", asset.mtime);
  }
  const contents = await readAsset(id);
  event.res.end(contents);
});

export { _static as default };
//# sourceMappingURL=static.mjs.map
