const client_manifest = {
  "node_modules/nuxt/dist/app/entry.mjs": {
    "file": "entry-f564636c.mjs",
    "src": "node_modules/nuxt/dist/app/entry.mjs",
    "isEntry": true,
    "dynamicImports": [
      "pages/index.vue"
    ],
    "css": [
      "entry.26e20241.css"
    ]
  },
  "pages/index.vue": {
    "file": "index-ee711130.mjs",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.mjs"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
