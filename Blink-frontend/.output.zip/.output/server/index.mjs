globalThis.entryURL = import.meta.url;export { n as default } from './chunks/nitro/node-server.mjs';
import 'unenv/runtime/polyfill/fetch.node';
import 'http';
import 'https';
import 'destr';
import 'h3';
import 'ohmyfetch';
import 'radix3';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'ohash';
import 'unstorage';
import 'ufo';
//# sourceMappingURL=index.mjs.map
